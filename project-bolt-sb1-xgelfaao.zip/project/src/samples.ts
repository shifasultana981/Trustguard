import type { SampleMessage } from "./types";

export const SAMPLE_MESSAGES: SampleMessage[] = [
  {
    id: "bank-otp",
    label: "Fake Bank OTP Message",
    shortLabel: "Bank OTP",
    icon: "landmark",
    content:
      "URGENT: Your Bank of America account has been temporarily suspended due to suspicious activity. " +
      "Reply with your OTP code sent to your phone to verify your identity and restore access immediately. " +
      "Failure to respond within 10 minutes will result in permanent account closure. " +
      "Do NOT share this code with anyone. Your code is 482917. Reply now to confirm.",
  },
  {
    id: "internship-fee",
    label: "Fake Internship Registration Fee",
    shortLabel: "Internship Fee",
    icon: "graduation-cap",
    content:
      "Congratulations! You have been selected for the Google Summer Internship Program 2026. " +
      "We were very impressed with your profile. To confirm your seat, please pay a one-time registration fee of $250 " +
      "via this link: http://google-intern-registration.co/pay?id=7723 " +
      "Limited seats available - only 3 spots left! Payment must be completed within 24 hours or your selection will be cancelled. " +
      "Contact HR Manager Sarah Williams on WhatsApp: +1-202-555-0188.",
  },
  {
    id: "delivery-payment",
    label: "Suspicious Delivery Payment",
    shortLabel: "Delivery Payment",
    icon: "package",
    content:
      "UPS: Your package #UP7283910ZZ is held at our facility due to unpaid shipping charges of $1.99. " +
      "Please complete payment now to avoid return to sender: http://ups-tracking-delivery.net/fees " +
      "Click here within 2 hours or your package will be destroyed. Thank you for choosing UPS.",
  },
];
