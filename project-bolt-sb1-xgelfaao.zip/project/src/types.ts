export type RiskLevel = "Low" | "Medium" | "High";

export interface WarningSign {
  id: string;
  label: string;
  description: string;
  evidence: string;
  weight: number;
}

export interface AnalysisResult {
  riskScore: number;
  riskLevel: RiskLevel;
  warningSigns: WarningSign[];
  explanation: string;
  recommendedActions: string[];
  submittedMessage: string;
  timestamp: string;
}

export interface SampleMessage {
  id: string;
  label: string;
  shortLabel: string;
  icon: string;
  content: string;
}
