import { AlertTriangle, ArrowRight, ShieldAlert, ShieldCheck, ShieldX, Lightbulb, FileSearch } from "lucide-react";
import type { AnalysisResult } from "@/types";

interface ResultsDisplayProps {
  result: AnalysisResult;
}

export default function ResultsDisplay({ result }: ResultsDisplayProps) {
  const isHigh = result.riskLevel === "High";
  const isMedium = result.riskLevel === "Medium";

  const ringColor = isHigh ? "#dc2626" : isMedium ? "#ea580c" : "#0d9488";
  const bgColor = isHigh ? "bg-red-50" : isMedium ? "bg-orange-50" : "bg-teal-50";
  const borderColor = isHigh ? "border-red-200" : isMedium ? "border-orange-200" : "border-teal-200";
  const textColor = isHigh ? "text-red-700" : isMedium ? "text-orange-700" : "text-teal-700";
  const badgeBg = isHigh ? "bg-red-600" : isMedium ? "bg-orange-500" : "bg-teal-600";

  const Icon = isHigh ? ShieldX : isMedium ? ShieldAlert : ShieldCheck;

  const chainSteps = [
    { label: "Submitted Message", value: "Message pasted and analyzed", icon: FileSearch },
    { label: "Warning Signs", value: `${result.warningSigns.length} indicator(s) found`, icon: AlertTriangle },
    { label: "Risk Assessment", value: `${result.riskLevel} risk — score ${result.riskScore}/100`, icon: Icon },
    { label: "Recommended Action", value: `${result.recommendedActions.length} safety action(s)`, icon: Lightbulb },
  ];

  return (
    <div className="space-y-6">
      {/* Risk Score Card */}
      <div className={`rounded-2xl border ${borderColor} ${bgColor} p-6 sm:p-8`}>
        <div className="flex flex-col sm:flex-row items-center gap-6">
          {/* Score Ring */}
          <div className="relative flex-shrink-0">
            <svg width="120" height="120" viewBox="0 0 120 120" className="transform -rotate-90">
              <circle cx="60" cy="60" r="52" fill="none" stroke="#e2e8f0" strokeWidth="10" />
              <circle
                cx="60"
                cy="60"
                r="52"
                fill="none"
                stroke={ringColor}
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={`${(result.riskScore / 100) * 327} 327`}
                style={{ transition: "stroke-dasharray 0.8s ease-out" }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={`text-3xl font-extrabold ${textColor}`}>{result.riskScore}</span>
              <span className="text-xs text-slate-400 font-medium">/ 100</span>
            </div>
          </div>

          {/* Risk Level + Explanation */}
          <div className="flex-1 text-center sm:text-left">
            <div className="flex items-center justify-center sm:justify-start gap-3 mb-2">
              <Icon className={`w-7 h-7 ${textColor}`} />
              <span className={`text-2xl font-bold ${textColor}`}>{result.riskLevel} Risk</span>
              <span className={`${badgeBg} text-white text-xs font-semibold px-3 py-1 rounded-full uppercase tracking-wide`}>
                {isHigh ? "Danger" : isMedium ? "Caution" : "Likely Safe"}
              </span>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">{result.explanation}</p>
          </div>
        </div>
      </div>

      {/* Warning Signs */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
        <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-500" />
          Warning Signs Detected ({result.warningSigns.length})
        </h3>
        {result.warningSigns.length === 0 ? (
          <p className="text-sm text-slate-500 italic">
            No significant warning signs were detected by the automated rules. This does NOT guarantee the message is safe.
          </p>
        ) : (
          <div className="space-y-3">
            {result.warningSigns.map((sign, i) => (
              <div
                key={sign.id}
                className={`rounded-xl border-l-4 p-4 ${isHigh ? "border-red-500 bg-red-50/50" : isMedium ? "border-orange-500 bg-orange-50/50" : "border-teal-500 bg-teal-50/50"}`}
              >
                <div className="flex items-start gap-3">
                  <span className={`flex-shrink-0 w-7 h-7 rounded-full text-white flex items-center justify-center text-xs font-bold ${badgeBg}`}>
                    {i + 1}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <span className="font-semibold text-sm text-slate-800">{sign.label}</span>
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded ${textColor} ${bgColor}`}>
                        +{sign.weight} pts
                      </span>
                    </div>
                    <p className="text-sm text-slate-600 mb-2">{sign.description}</p>
                    <div className="text-xs text-slate-500 bg-white border border-slate-200 rounded-lg px-3 py-2">
                      <span className="font-semibold text-slate-700">Evidence: </span>
                      {sign.evidence}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Evidence Chain */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
        <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-6 flex items-center gap-2">
          <FileSearch className="w-4 h-4 text-teal-600" />
          Evidence Chain
        </h3>
        <div className="flex flex-col sm:flex-row gap-2 sm:gap-0 sm:items-stretch">
          {chainSteps.map((step, i) => {
            const StepIcon = step.icon;
            return (
              <div key={i} className="flex items-center gap-2 sm:flex-1">
                <div className="flex-1 rounded-xl border border-slate-200 bg-slate-50 p-4 text-center">
                  <div className={`w-10 h-10 mx-auto rounded-full flex items-center justify-center mb-2 ${i === 2 ? badgeBg : "bg-slate-800"} text-white`}>
                    <StepIcon className="w-5 h-5" />
                  </div>
                  <div className="text-xs font-bold text-slate-800 uppercase tracking-wide mb-1">
                    Step {i + 1}
                  </div>
                  <div className="text-sm font-semibold text-slate-700">{step.label}</div>
                  <div className="text-xs text-slate-500 mt-1">{step.value}</div>
                </div>
                {i < chainSteps.length - 1 && (
                  <div className="flex items-center justify-center sm:px-1">
                    <ArrowRight className="w-5 h-5 text-slate-300 rotate-90 sm:rotate-0" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Recommended Actions */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
        <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-2">
          <Lightbulb className="w-4 h-4 text-amber-500" />
          Recommended Safety Actions
        </h3>
        <ul className="space-y-2">
          {result.recommendedActions.map((action, i) => (
            <li key={i} className="flex items-start gap-3 py-2 border-b border-slate-100 last:border-0">
              <span className="flex-shrink-0 w-6 h-6 rounded-full bg-teal-600 text-white flex items-center justify-center text-xs font-bold mt-0.5">
                {i + 1}
              </span>
              <span className="text-sm text-slate-700 leading-relaxed">{action}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
