import { ShieldCheck, Info, AlertCircle } from "lucide-react";
import { useState } from "react";

export default function AboutSection() {
  const [open, setOpen] = useState(false);

  return (
    <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-6 py-4 hover:bg-slate-50 transition-colors"
      >
        <span className="flex items-center gap-2 text-sm font-bold text-slate-800 uppercase tracking-wider">
          <Info className="w-4 h-4 text-teal-600" />
          About TrustGuard &amp; Limitations
        </span>
        <span className="text-slate-400 text-xs">{open ? "Collapse" : "Expand"}</span>
      </button>
      {open && (
        <div className="px-6 pb-6 space-y-5 text-sm text-slate-600 leading-relaxed">
          <div>
            <h4 className="font-semibold text-slate-800 mb-1.5 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-teal-600" />
              About TrustGuard
            </h4>
            <p>
              TrustGuard is an automated, rule-based message analysis tool built for a cybersecurity hackathon.
              It examines suspicious SMS messages, emails, and recruiter messages for common scam indicators —
              including urgency tactics, credential requests, payment demands, suspicious links, brand impersonation,
              and too-good-to-be-true offers. Every check runs locally in your browser using transparent JavaScript rules.
              No data is sent to any external server.
            </p>
          </div>

          <div className="rounded-xl bg-amber-50 border border-amber-200 p-4">
            <h4 className="font-semibold text-amber-800 mb-1.5 flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              Limitations
            </h4>
            <ul className="space-y-1.5 text-amber-700">
              <li>Results are <strong>automated preliminary checks</strong>, not guaranteed scam detection.</li>
              <li>TrustGuard does <strong>not</strong> independently verify websites, phone numbers, email addresses, or sender identities.</li>
              <li>Sophisticated or novel scam techniques may not be detected by the current rule set.</li>
              <li>A &ldquo;Low&rdquo; risk score does <strong>not</strong> mean a message is safe — it means no known indicators were found.</li>
              <li>This tool is for educational and awareness purposes and should not replace professional cybersecurity advice.</li>
              <li>Always verify suspicious messages through independent, official channels.</li>
            </ul>
          </div>

          <div className="rounded-xl bg-teal-50 border border-teal-200 p-4">
            <h4 className="font-semibold text-teal-800 mb-1.5">How It Works</h4>
            <p className="text-teal-700">
              TrustGuard analyzes your message against a set of transparent rules, each weighted by severity.
              The total weight of matched rules produces a risk score from 0 to 100. Scores below 25 are
              classified as Low risk, 25–49 as Medium, and 50+ as High. The specific rules triggered, the
              evidence found, and recommended actions are all displayed for your review.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
