import type { AnalysisResult, RiskLevel, WarningSign } from "./types";

interface RuleMatch {
  sign: Omit<WarningSign, "evidence">;
  evidence: string;
}

const URL_REGEX = /https?:\/\/[^\s]+/gi;
const SHORTENED_URL_REGEX = /https?:\/\/(?:bit\.ly|tinyurl\.com|t\.co|goo\.gl|ow\.ly|is\.gd|buff\.ly)\/[^\s]+/gi;
const SUSPICIOUS_TLD_REGEX = /https?:\/\/[^\s]+?\.(?:tk|ml|ga|cf|xyz|top|click|country|gq|cn|ru|co\.cc)\b/gi;

const URGENT_WORDS = [
  "urgent", "immediately", "right now", "within \\d+ (?:minutes?|hours?|days?)",
  "expires?", "deadline", "act now", "don'?t delay", "hurry", "limited time",
  "final notice", "last chance", "last warning", "must (?:respond|confirm|pay|verify)",
  "failure to", "will be (?:closed|cancelled|suspended|terminated|blocked|destroyed)",
  "permanent (?:closure|block|ban)",
];

const OTP_KEYWORDS = ["otp", "one[-\\s]?time (?:password|code|pin)", "verification code", "verify code",
  "security code", "auth code", "confirm(?:ation)? code", "your code is", "do not share (?:this )?code",
  "password", "pin number", "cvv", "card number", "account number", "social security", "ssn"];

const IMPERSONATION_BRANDS = [
  "bank of america", "chase", "wells fargo", "citibank", "hsbc", "barclays", "santander",
  "google", "amazon", "apple", "microsoft", "netflix", "paypal", "venmo", "zelle",
  "ups", "fedex", "usps", "dhl", "post office", "royal mail",
  "facebook", "instagram", "whatsapp", "linkedin", "tiktok",
  "irs", "hmrc", "social security administration", "dmv", "government",
  "walmart", "target", "costco", "best buy",
];

const PAYMENT_KEYWORDS = [
  "pay(?:ment)?", "fee", "charge", "deposit", "transfer", "wire", "send money",
  "wire transfer", "western union", "moneygram", "bitcoin", "crypto", "gift card",
  "registration fee", "processing fee", "shipping (?:fee|charge)", "clearance fee",
  "customs fee", "release fee", "\\\\$\\d+", "usd", "naira", "rupees?",
];

const TOO_GOOD_KEYWORDS = [
  "congratulations?", "you(?:'?ve| have) (?:won|been selected|been chosen|been shortlisted)",
  "winner", "prize", "lottery", "sweepstakes", "free (?:gift|iphone|money|voucher|prize)",
  "guaranteed (?:return|profit|income|approval|loan|placement)",
  "risk[-\\s]?free", "no risk", "double your money", "easy money",
  "work from home", "earn \\$?\\d+ (?:per|a|/) (?:day|week|hour|month)",
  "investment opportunity", "high returns?", "get rich",
  "you are among the (?:lucky |few )?(?:selected|chosen|winners)",
  "job offer", "job selected", "employment offer", "hired",
];

const IMPERSONATION_PATTERNS = [
  "hr manager", "hiring manager", "recruitment (?:team|officer|manager|department)",
  "customer (?:service|support|care)", "support team", "security team",
  "verification (?:team|department|center|unit)", "fraud (?:team|department|prevention)",
  "account (?:team|department|services)", "billing department",
  "this is (?:your|the) bank", "dear (?:customer|user|client|valued customer|account holder)",
  "dear (?:sir|madam|member|winner|applicant|candidate)",
];

const SUSPICIOUS_REQUESTS = [
  "whatsapp", "telegram", "signal", "text (?:me|us) (?:at|on)", "call (?:me|us) (?:at|on)",
  "reply (?:with|to)", "send (?:your|us) (?:details?|information|info|documents?|id|photo)",
  "confirm your (?:identity|account|details?|address|payment)",
  "update your (?:details?|information|payment|card|account)",
  "kyc", "verify your (?:identity|account|address)",
];

function findMatches(text: string, patterns: string[], flags = "gi"): string[] {
  const matches: string[] = [];
  for (const p of patterns) {
    const regex = new RegExp(p, flags);
    let m: RegExpExecArray | null;
    while ((m = regex.exec(text)) !== null) {
      matches.push(m[0]);
      if (regex.lastIndex === m.index) regex.lastIndex++;
    }
  }
  return matches;
}

function findFirstMatch(text: string, patterns: string[], flags = "gi"): string | null {
  const matches = findMatches(text, patterns, flags);
  return matches.length > 0 ? matches[0] : null;
}

function collectMatches(text: string): RuleMatch[] {
  const lower = text.toLowerCase();
  const matches: RuleMatch[] = [];

  // 1. Urgency / Pressure
  const urgencyMatches = findMatches(lower, URGENT_WORDS);
  if (urgencyMatches.length > 0) {
    matches.push({
      sign: {
        id: "urgency",
        label: "Urgency & Pressure Tactics",
        description:
          "The message creates artificial time pressure, a common scam technique to prevent careful thinking.",
        weight: 15,
      },
      evidence: urgencyMatches.slice(0, 3).map((m) => `"${m}"`).join(", "),
    });
  }

  // 2. OTP / Password / Credential Requests
  const otpMatches = findMatches(lower, OTP_KEYWORDS);
  if (otpMatches.length > 0) {
    matches.push({
      sign: {
        id: "credential-request",
        label: "Requests for Sensitive Credentials",
        description:
          "The message asks for OTPs, passwords, PINs, or other credentials. Legitimate organizations never ask for these.",
        weight: 25,
      },
      evidence: otpMatches.slice(0, 3).map((m) => `"${m}"`).join(", "),
    });
  }

  // 3. Payment / Money Demands
  const paymentMatches = findMatches(lower, PAYMENT_KEYWORDS);
  if (paymentMatches.length > 0) {
    matches.push({
      sign: {
        id: "payment-demand",
        label: "Payment or Money Transfer Demand",
        description:
          "The message requests payment, fees, or money transfers. Be extremely cautious of unsolicited payment requests.",
        weight: 20,
      },
      evidence: paymentMatches.slice(0, 3).map((m) => `"${m}"`).join(", "),
    });
  }

  // 4. Suspicious Links
  const urls = text.match(URL_REGEX) || [];
  const shortenedUrls = text.match(SHORTENED_URL_REGEX) || [];
  const suspiciousTldUrls = text.match(SUSPICIOUS_TLD_REGEX) || [];

  if (urls.length > 0) {
    const linkEvidence: string[] = [];
    if (shortenedUrls.length > 0) {
      linkEvidence.push(`Shortened URL(s): ${shortenedUrls.slice(0, 2).join(", ")}`);
    }
    if (suspiciousTldUrls.length > 0) {
      linkEvidence.push(`Suspicious domain extension(s): ${suspiciousTldUrls.slice(0, 2).join(", ")}`);
    }
    // Check for brand impersonation in URLs
    for (const url of urls) {
      const urlLower = url.toLowerCase();
      for (const brand of IMPERSONATION_BRANDS) {
        const brandSlug = brand.replace(/\s+/g, "");
        if (urlLower.includes(brandSlug) && !isLegitimateDomain(urlLower, brand)) {
          linkEvidence.push(`Link mimics "${brand}" but is not the official domain`);
          break;
        }
      }
    }

    matches.push({
      sign: {
        id: "suspicious-links",
        label: "Suspicious Links Detected",
        description:
          "The message contains links that may be shortened, use suspicious domain extensions, or mimic legitimate brands.",
        weight: shortenedUrls.length > 0 || suspiciousTldUrls.length > 0 ? 20 : 12,
      },
      evidence: linkEvidence.length > 0 ? linkEvidence.join("; ") : `Link(s) found: ${urls.slice(0, 2).join(", ")}`,
    });
  }

  // 5. Impersonation of Known Brands
  const brandMatches = findMatches(lower, IMPERSONATION_BRANDS);
  if (brandMatches.length > 0) {
    const uniqueBrands = [...new Set(brandMatches)];
    matches.push({
      sign: {
        id: "impersonation",
        label: "Brand or Organization Impersonation",
        description:
          "The message references well-known brands or organizations. Verify any claims independently through official channels.",
        weight: 18,
      },
      evidence: `References: ${uniqueBrands.slice(0, 3).map((b) => `"${b}"`).join(", ")}`,
    });
  }

  // 6. Unofficial Contact Channels
  const contactMatches = findMatches(lower, SUSPICIOUS_REQUESTS);
  if (contactMatches.length > 0) {
    matches.push({
      sign: {
        id: "unofficial-contact",
        label: "Redirects to Unofficial Communication Channel",
        description:
          "The message asks you to move the conversation to WhatsApp, Telegram, or another personal channel, bypassing official platforms.",
        weight: 12,
      },
      evidence: contactMatches.slice(0, 3).map((m) => `"${m}"`).join(", "),
    });
  }

  // 7. Too-Good-To-Be-True Offers
  const tgMatches = findMatches(lower, TOO_GOOD_KEYWORDS);
  if (tgMatches.length > 0) {
    matches.push({
      sign: {
        id: "too-good",
        label: "Too-Good-To-Be-True Offer",
        description:
          "The message promises prizes, guaranteed income, job offers, or free items with little to no effort on your part.",
        weight: 16,
      },
      evidence: tgMatches.slice(0, 3).map((m) => `"${m}"`).join(", "),
    });
  }

  // 8. Impersonation of Authority Figures
  const authorityMatches = findMatches(lower, IMPERSONATION_PATTERNS);
  if (authorityMatches.length > 0) {
    matches.push({
      sign: {
        id: "authority-impersonation",
        label: "Claims Authority Without Verification",
        description:
          "The sender claims to be an official representative, HR manager, or security team without any verifiable proof.",
        weight: 10,
      },
      evidence: authorityMatches.slice(0, 3).map((m) => `"${m}"`).join(", "),
    });
  }

  // 9. Generic / Non-personalized Greeting
  if (/dear (?:customer|user|client|valued customer|account holder|sir|madam|member|winner)/i.test(text)) {
    matches.push({
      sign: {
        id: "generic-greeting",
        label: "Generic, Non-Personalized Greeting",
        description:
          "Legitimate institutions usually address you by name. Generic greetings are common in mass-sent scam messages.",
        weight: 6,
      },
      evidence: "Generic greeting detected",
    });
  }

  // 10. Request to Share Code
  if (/reply (?:with|to|back)|send (?:us|me)? ?(?:the )?code|confirm(?:ation)? (?:code|otp)/i.test(lower)) {
    matches.push({
      sign: {
        id: "reply-with-code",
        label: "Asks You to Reply or Send a Code",
        description:
          "Asking you to reply with a code or confirm an OTP is a red flag. Real institutions never ask you to share codes back.",
        weight: 14,
      },
      evidence: "Reply/send code request detected",
    });
  }

  // Deduplicate by sign id (keep highest-weight evidence)
  const seen = new Map<string, RuleMatch>();
  for (const m of matches) {
    if (!seen.has(m.sign.id)) {
      seen.set(m.sign.id, m);
    }
  }

  return Array.from(seen.values());
}

function isLegitimateDomain(url: string, brand: string): boolean {
  const legitMap: Record<string, string[]> = {
    "bank of america": ["bankofamerica.com"],
    "google": ["google.com", "google.co"],
    "amazon": ["amazon.com", "amazon.co"],
    "apple": ["apple.com"],
    "microsoft": ["microsoft.com"],
    "ups": ["ups.com"],
    "fedex": ["fedex.com"],
    "usps": ["usps.com"],
    "paypal": ["paypal.com"],
    "netflix": ["netflix.com"],
  };
  const legit = legitMap[brand] || [];
  for (const d of legit) {
    if (url.includes(`://${d}`) || url.includes(`.${d}`)) return true;
  }
  return false;
}

function calculateScore(matches: RuleMatch[]): number {
  let score = 0;
  for (const m of matches) {
    score += m.sign.weight;
  }
  return Math.min(score, 100);
}

function getRiskLevel(score: number): RiskLevel {
  if (score >= 50) return "High";
  if (score >= 25) return "Medium";
  return "Low";
}

function buildExplanation(warningSigns: WarningSign[], riskLevel: RiskLevel, score: number): string {
  if (warningSigns.length === 0) {
    return "No significant warning signs were detected by our automated rules. This does NOT mean the message is safe — it may use tactics our checks do not cover. Always exercise caution with unsolicited messages.";
  }

  const count = warningSigns.length;
  const level = riskLevel.toLowerCase();

  if (riskLevel === "High") {
    return `This message triggered ${count} warning sign${count > 1 ? "s" : ""}, resulting in a HIGH risk score of ${score}. Multiple strong indicators of fraud were found, including requests for sensitive information, payment demands, or impersonation. We strongly recommend you do NOT respond, click any links, or share any information.`;
  }
  if (riskLevel === "Medium") {
    return `This message triggered ${count} warning sign${count > 1 ? "s" : ""}, resulting in a MEDIUM risk score of ${score}. Some concerning patterns were detected. Exercise caution — verify the sender through independent, official channels before taking any action.`;
  }
  return `This message triggered ${count} minor warning sign${count > 1 ? "s" : ""}, resulting in a LOW risk score of ${score}. While no major red flags were found, always remain cautious with unsolicited messages. When in doubt, verify independently.`;
}

function buildActions(warningSigns: WarningSign[], riskLevel: RiskLevel): string[] {
  const actions: string[] = [];

  const hasIds = new Set(warningSigns.map((w) => w.id));

  if (riskLevel === "High") {
    actions.push("Do NOT reply to this message, click any links, or share any information.");
    actions.push("Delete the message and block the sender if possible.");
    actions.push("If you already shared information or paid, contact your bank immediately and report the incident.");
  } else if (riskLevel === "Medium") {
    actions.push("Do not click any links or share personal information until you verify the sender independently.");
    actions.push("Contact the organization directly using their official website or phone number — not the details in this message.");
  } else {
    actions.push("Remain cautious. Verify the sender through an independent, trusted channel if you are unsure.");
  }

  if (hasIds.has("credential-request")) {
    actions.push("Never share OTPs, passwords, or PINs with anyone — no legitimate organization will ask for them.");
  }
  if (hasIds.has("payment-demand")) {
    actions.push("Do not make any payment. Legitimate recruiters, banks, and delivery services do not ask for upfront fees via message links.");
  }
  if (hasIds.has("suspicious-links")) {
    actions.push("Do not click any links in the message. If you need to check an account, type the official website address directly into your browser.");
  }
  if (hasIds.has("impersonation")) {
    actions.push("Verify any brand or organization claims by contacting them through their official website or verified customer service number.");
  }
  if (hasIds.has("unofficial-contact")) {
    actions.push("Do not move the conversation to WhatsApp, Telegram, or other personal messaging apps. Official recruiters and companies communicate through official channels.");
  }
  if (hasIds.has("too-good")) {
    actions.push("Be skeptical of prizes, job offers, or guaranteed income that require upfront payment or personal details.");
  }

  actions.push("Report suspicious messages to your local fraud / cybercrime reporting authority.");

  return [...new Set(actions)];
}

export function analyzeMessage(text: string): AnalysisResult {
  const rawMatches = collectMatches(text);
  const warningSigns: WarningSign[] = rawMatches.map((m) => ({
    ...m.sign,
    evidence: m.evidence,
  }));
  const riskScore = calculateScore(rawMatches);
  const riskLevel = getRiskLevel(riskScore);
  const explanation = buildExplanation(warningSigns, riskLevel, riskScore);
  const recommendedActions = buildActions(warningSigns, riskLevel);

  return {
    riskScore,
    riskLevel,
    warningSigns,
    explanation,
    recommendedActions,
    submittedMessage: text,
    timestamp: new Date().toLocaleString(),
  };
}
