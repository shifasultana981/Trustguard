import { useState, useRef, useEffect } from "react";
import {
  ShieldCheck, Search, Trash2, FileText, Landmark, GraduationCap, Package,
  AlertCircle, Loader2, Scale, Lock, Sparkles,
} from "lucide-react";
import type { AnalysisResult } from "@/types";
import { SAMPLE_MESSAGES } from "@/samples";
import { analyzeMessage } from "@/analyzer";
import { generateReport } from "@/report";
import ResultsDisplay from "@/components/ResultsDisplay";
import AboutSection from "@/components/AboutSection";

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  landmark: Landmark,
  "graduation-cap": GraduationCap,
  package: Package,
};

export default function App() {
  const [inputText, setInputText] = useState("");
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const resultsRef = useRef<HTMLDivElement>(null);

  const handleInvestigate = () => {
    const trimmed = inputText.trim();
    if (trimmed.length < 10) {
      setError("Please paste a message of at least 10 characters to analyze.");
      setResult(null);
      return;
    }
    setError("");
    setLoading(true);
    setResult(null);

    setTimeout(() => {
      try {
        const analysis = analyzeMessage(inputText);
        setResult(analysis);
      } catch (err) {
        setError("Something went wrong while analyzing the message. Please try again or paste a different message.");
        setResult(null);
      } finally {
        setLoading(false);
      }
    }, 700);
  };

  const handleClear = () => {
    setInputText("");
    setResult(null);
    setError("");
  };

  const handleSample = (content: string) => {
    setInputText(content);
    setResult(null);
    setError("");
  };

  const handleReport = () => {
    if (!result) return;
    generateReport(result);
  };

  useEffect(() => {
    if (result && resultsRef.current) {
      resultsRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [result]);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-teal-500/20 border border-teal-400/30 flex items-center justify-center flex-shrink-0">
              <ShieldCheck className="w-6 h-6 text-teal-400" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight">TrustGuard</h1>
              <p className="text-teal-400 text-sm italic">Investigate before you trust</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-8">
        {/* Intro banner */}
        <div className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-6">
          <p className="text-slate-600 text-sm leading-relaxed">
            Paste a suspicious SMS, email, or recruiter message below and TrustGuard will analyze it for
            common scam indicators — completely in your browser. No data leaves your device.
          </p>
          <div className="flex flex-wrap gap-4 mt-3 text-xs text-slate-400">
            <span className="flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-teal-500" /> 100% Local Analysis
            </span>
            <span className="flex items-center gap-1.5">
              <Scale className="w-3.5 h-3.5 text-teal-500" /> Transparent Rules
            </span>
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-teal-500" /> No External API
            </span>
          </div>
        </div>

        {/* Input Section */}
        <div className="rounded-2xl bg-white border border-slate-200 p-5 sm:p-8 space-y-5">
          <div>
            <label htmlFor="message-input" className="block text-sm font-bold text-slate-800 uppercase tracking-wider mb-3">
              Paste Suspicious Message
            </label>
            <textarea
              id="message-input"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Paste the suspicious SMS, email, or message you received here..."
              className="w-full h-40 sm:h-48 px-4 py-3 rounded-xl border border-slate-300 bg-slate-50 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent resize-y transition-all"
            />
            <div className="flex justify-between items-center mt-2">
              <span className="text-xs text-slate-400">{inputText.trim().length} characters</span>
              {error && (
                <span className="text-xs text-red-600 flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5" />
                  {error}
                </span>
              )}
            </div>
          </div>

          {/* Sample Buttons */}
          <div>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2.5">
              Try a Sample Message
            </p>
            <div className="flex flex-col sm:flex-row gap-2.5">
              {SAMPLE_MESSAGES.map((sample) => {
                const Icon = ICON_MAP[sample.icon] || FileText;
                return (
                  <button
                    key={sample.id}
                    onClick={() => handleSample(sample.content)}
                    className="flex-1 flex items-center gap-2.5 px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-teal-50 hover:border-teal-300 transition-all text-left group"
                  >
                    <Icon className="w-4 h-4 text-slate-500 group-hover:text-teal-600 flex-shrink-0" />
                    <span className="text-xs font-semibold text-slate-700 group-hover:text-teal-700">
                      {sample.shortLabel}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={handleInvestigate}
              disabled={loading}
              className="flex-1 flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white font-semibold text-sm transition-all disabled:opacity-60 disabled:cursor-not-allowed shadow-sm hover:shadow-md"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Investigating...
                </>
              ) : (
                <>
                  <Search className="w-5 h-5" />
                  Investigate Threat
                </>
              )}
            </button>
            <button
              onClick={handleClear}
              className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl border border-slate-300 hover:border-slate-400 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-sm transition-all"
            >
              <Trash2 className="w-4 h-4" />
              Clear
            </button>
            <button
              onClick={handleReport}
              disabled={!result || loading}
              className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl border border-slate-300 hover:border-slate-400 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-sm transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <FileText className="w-4 h-4" />
              Generate Trust Report
            </button>
          </div>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="rounded-2xl bg-white border border-slate-200 p-12 text-center">
            <Loader2 className="w-10 h-10 text-teal-500 animate-spin mx-auto mb-4" />
            <p className="text-slate-500 text-sm">Analyzing message against scam detection rules...</p>
            <div className="flex justify-center gap-1.5 mt-4">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="w-2 h-2 rounded-full bg-teal-400 animate-bounce"
                  style={{ animationDelay: `${i * 150}ms` }}
                />
              ))}
            </div>
          </div>
        )}

        {/* Results */}
        {result && !loading && (
          <div ref={resultsRef}>
            <ResultsDisplay result={result} />
          </div>
        )}

        {/* Disclaimer */}
        <div className="rounded-xl bg-amber-50 border border-amber-200 px-5 py-4">
          <p className="text-xs text-amber-700 leading-relaxed">
            <strong>Important:</strong> TrustGuard provides automated preliminary checks only. It is not a
            guaranteed scam detection system. No websites, phone numbers, or identities were independently
            verified. Always use your own judgment and verify through official channels.
          </p>
        </div>

        {/* About & Limitations */}
        <AboutSection />

        {/* Footer */}
        <footer className="text-center pt-4 pb-8">
          <p className="text-xs text-slate-400">
            TrustGuard — Investigate before you trust. Built for a cybersecurity hackathon.
          </p>
        </footer>
      </main>
    </div>
  );
}
