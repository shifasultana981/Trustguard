import type { AnalysisResult } from "./types";

export function generateReport(result: AnalysisResult): void {
  const riskColor =
    result.riskLevel === "High" ? "#dc2626" : result.riskLevel === "Medium" ? "#ea580c" : "#0d9488";
  const riskBg =
    result.riskLevel === "High" ? "#fef2f2" : result.riskLevel === "Medium" ? "#fff7ed" : "#f0fdfa";

  const signsHtml = result.warningSigns
    .map(
      (sign, i) => `
      <div class="sign">
        <div class="sign-header">
          <span class="sign-number">${i + 1}</span>
          <span class="sign-label">${sign.label}</span>
          <span class="sign-weight">+${sign.weight} pts</span>
        </div>
        <div class="sign-desc">${sign.description}</div>
        <div class="sign-evidence"><strong>Evidence:</strong> ${sign.evidence}</div>
      </div>`
    )
    .join("");

  const actionsHtml = result.recommendedActions
    .map(
      (action, i) =>
        `<li><span class="action-num">${i + 1}</span><span>${action}</span></li>`
    )
    .join("");

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>TrustGuard Investigation Report</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; background: #f8fafc; color: #1e293b; line-height: 1.6; padding: 24px; }
  .report { max-width: 800px; margin: 0 auto; background: white; border-radius: 12px; box-shadow: 0 4px 24px rgba(0,0,0,0.08); overflow: hidden; }
  .header { background: #0f172a; color: white; padding: 32px; text-align: center; }
  .header h1 { font-size: 28px; font-weight: 700; letter-spacing: -0.5px; }
  .header .tagline { color: #14b8a6; font-size: 14px; margin-top: 6px; font-style: italic; }
  .header .timestamp { color: #94a3b8; font-size: 12px; margin-top: 12px; }
  .disclaimer { background: #fffbeb; border-bottom: 1px solid #fde68a; padding: 14px 24px; font-size: 13px; color: #92400e; text-align: center; }
  .section { padding: 24px 32px; border-bottom: 1px solid #e2e8f0; }
  .section:last-child { border-bottom: none; }
  .section-title { font-size: 14px; font-weight: 700; color: #0f172a; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; }
  .section-title .dot { width: 8px; height: 8px; border-radius: 50%; background: #14b8a6; }
  .message-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; font-size: 14px; white-space: pre-wrap; word-break: break-word; }
  .risk-display { display: flex; align-items: center; gap: 24px; }
  .risk-score-ring { width: 100px; height: 100px; border-radius: 50%; display: flex; flex-direction: column; align-items: center; justify-content: center; background: ${riskBg}; border: 4px solid ${riskColor}; flex-shrink: 0; }
  .risk-score-ring .score { font-size: 32px; font-weight: 800; color: ${riskColor}; line-height: 1; }
  .risk-score-ring .label { font-size: 11px; color: ${riskColor}; font-weight: 600; text-transform: uppercase; margin-top: 2px; }
  .risk-info h3 { font-size: 20px; font-weight: 700; color: ${riskColor}; }
  .risk-info p { font-size: 13px; color: #64748b; margin-top: 4px; }
  .sign { margin-bottom: 16px; padding: 16px; background: #f8fafc; border-radius: 8px; border-left: 4px solid ${riskColor}; }
  .sign:last-child { margin-bottom: 0; }
  .sign-header { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; flex-wrap: wrap; }
  .sign-number { background: ${riskColor}; color: white; width: 22px; height: 22px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; flex-shrink: 0; }
  .sign-label { font-weight: 600; font-size: 14px; color: #1e293b; flex: 1; }
  .sign-weight { font-size: 12px; color: ${riskColor}; font-weight: 600; background: ${riskBg}; padding: 2px 8px; border-radius: 4px; }
  .sign-desc { font-size: 13px; color: #475569; margin-bottom: 6px; }
  .sign-evidence { font-size: 12px; color: #64748b; background: white; padding: 8px 10px; border-radius: 4px; border: 1px solid #e2e8f0; }
  .actions-list { list-style: none; padding: 0; }
  .actions-list li { display: flex; gap: 10px; padding: 10px 0; border-bottom: 1px solid #f1f5f9; font-size: 14px; color: #334155; }
  .actions-list li:last-child { border-bottom: none; }
  .action-num { background: #14b8a6; color: white; width: 22px; height: 22px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 700; flex-shrink: 0; margin-top: 2px; }
  .chain { display: flex; flex-direction: column; gap: 0; }
  .chain-step { display: flex; gap: 12px; padding: 12px 0; }
  .chain-step:not(:last-child)::after { content: ''; position: absolute; }
  .chain-num { width: 28px; height: 28px; border-radius: 50%; background: #0f172a; color: white; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 700; flex-shrink: 0; }
  .chain-content h4 { font-size: 14px; font-weight: 600; color: #0f172a; }
  .chain-content p { font-size: 13px; color: #64748b; margin-top: 2px; }
  .footer { padding: 20px 32px; background: #f8fafc; text-align: center; font-size: 12px; color: #94a3b8; }
  .footer a { color: #14b8a6; text-decoration: none; }
  .print-btn { position: fixed; bottom: 24px; right: 24px; background: #0f172a; color: white; border: none; padding: 12px 24px; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; box-shadow: 0 4px 12px rgba(0,0,0,0.15); transition: background 0.2s; }
  .print-btn:hover { background: #1e293b; }
  @media print {
    .print-btn { display: none; }
    body { padding: 0; background: white; }
    .report { box-shadow: none; border-radius: 0; }
  }
  @media (max-width: 640px) {
    body { padding: 8px; }
    .header { padding: 20px; }
    .header h1 { font-size: 22px; }
    .section { padding: 16px 20px; }
    .risk-display { flex-direction: column; text-align: center; }
  }
</style>
</head>
<body>
<div class="report">
  <div class="header">
    <h1>TrustGuard Investigation Report</h1>
    <div class="tagline">Investigate before you trust</div>
    <div class="timestamp">Generated: ${result.timestamp}</div>
  </div>
  <div class="disclaimer">
    <strong>Automated Preliminary Check:</strong> This report is generated by transparent, rule-based analysis. It is NOT a guaranteed scam detection system. No websites, phone numbers, or identities were independently verified.
  </div>

  <div class="section">
    <div class="section-title"><span class="dot"></span> Submitted Message</div>
    <div class="message-box">${escapeHtml(result.submittedMessage)}</div>
  </div>

  <div class="section">
    <div class="section-title"><span class="dot"></span> Risk Assessment</div>
    <div class="risk-display">
      <div class="risk-score-ring">
        <div class="score">${result.riskScore}</div>
        <div class="label">/ 100</div>
      </div>
      <div class="risk-info">
        <h3>${result.riskLevel} Risk</h3>
        <p>${result.explanation}</p>
      </div>
    </div>
  </div>

  <div class="section">
    <div class="section-title"><span class="dot"></span> Warning Signs Detected (${result.warningSigns.length})</div>
    ${signsHtml || '<p style="color:#64748b;font-size:14px;">No significant warning signs were detected by the automated rules.</p>'}
  </div>

  <div class="section">
    <div class="section-title"><span class="dot"></span> Evidence Chain</div>
    <div class="chain">
      <div class="chain-step">
        <div class="chain-num">1</div>
        <div class="chain-content">
          <h4>Submitted Message</h4>
          <p>Suspicious message pasted and submitted for analysis</p>
        </div>
      </div>
      <div class="chain-step">
        <div class="chain-num">2</div>
        <div class="chain-content">
          <h4>Warning Signs</h4>
          <p>${result.warningSigns.length} indicator(s) identified by rule-based checks</p>
        </div>
      </div>
      <div class="chain-step">
        <div class="chain-num">3</div>
        <div class="chain-content">
          <h4>Risk Assessment</h4>
          <p>${result.riskLevel} risk — score of ${result.riskScore} out of 100</p>
        </div>
      </div>
      <div class="chain-step">
        <div class="chain-num">4</div>
        <div class="chain-content">
          <h4>Recommended Action</h4>
          <p>${result.recommendedActions.length} safety action(s) provided</p>
        </div>
      </div>
    </div>
  </div>

  <div class="section">
    <div class="section-title"><span class="dot"></span> Recommended Safety Actions</div>
    <ul class="actions-list">
      ${actionsHtml}
    </ul>
  </div>

  <div class="footer">
    <p>This report was generated by <strong>TrustGuard</strong> — an automated, rule-based message analysis tool.</p>
    <p style="margin-top:4px;">Results are preliminary and should not replace professional judgment. &copy; ${new Date().getFullYear()} TrustGuard</p>
  </div>
</div>
<button class="print-btn" onclick="window.print()">Print / Save as PDF</button>
</body>
</html>`;

  const blob = new Blob([html], { type: "text/html" });
  const url = URL.createObjectURL(blob);
  const win = window.open(url, "_blank");
  if (win) {
    win.onload = () => URL.revokeObjectURL(url);
  } else {
    URL.revokeObjectURL(url);
  }
}

function escapeHtml(text: string): string {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}
